class Talaba:
    def __init__(self, name, age):
        self.name = name
        self.age = age

class Kurs:
    def __init__(self, kurs_name, kurs_teacher):
        self.kurs_name = kurs_name
        self.kurs_teacher = kurs_teacher
        self.talabalar_soni = 0
        self.talabalar = []

    def add(self, new_student):
        self.talabalar.append(new_student)
        self.talabalar_soni += 1

    def delete(self, student_name):
        for student in self.talabalar:
            if student.name == student_name:
                self.talabalar.remove(student)
                self.talabalar_soni -= 1
                break

    def info_kurs(self):
        info = f"Kurs: {self.kurs_name}, O'qituvchi: {self.kurs_teacher}, "
        info += f"Talabalar soni: {self.talabalar_soni}\nTalabalar:\n"
        for student in self.talabalar:
            info += f"- {student.name} ({student.age} yosh)\n"
        return info

kurs1 = Kurs("Matematika", "Olimov")
kurs2 = Kurs("Ingliz tili", "Abdullayeva")

for i in range(1, 11):
    kurs1.add(Talaba(f"Talaba{i}", 20+i))
    kurs2.add(Talaba(f"Student{i}", 19+i))

kurs1.delete("Talaba1")
kurs2.delete("Student2")

print(kurs1.info_kurs())
print(kurs2.info_kurs())
