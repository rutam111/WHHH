class EngAlphabet:
    def __init__(self):
        self.language = "English"
        self.letters = list("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
        self.num_letters = len(self.letters)

    def count_letters(self):
        return self.num_letters

    def is_letter_in_alphabet(self, letter):
        return letter.upper() in self.letters

    def example_sentence(self):
        return "The quick brown fox jumps over the lazy dog."

english_alphabet = EngAlphabet()

print(english_alphabet.letters)

print(english_alphabet.count_letters())

print(english_alphabet.is_letter_in_alphabet('F'))

print(english_alphabet.is_letter_in_alphabet('Щ'))

print(english_alphabet.example_sentence())
