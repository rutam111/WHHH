class Telegram:
    def __init__(self, user_name):
        self.user_name = user_name
        self.send_chat_text = ""
        self.accept_chat_text = ""
        self.chat_status = "inactive"
        self.chat_time = None

    def send(self, other, text):
        self.send_chat_text = text
        self.chat_status = "sending"
        other.accept_chat_text = text
        other.chat_status = "receiving"

    def read(self):
        if self.accept_chat_text:
            print(f"{self.user_name} received: {self.accept_chat_text}")
            self.chat_status = "reading"

    def delete(self):
        self.accept_chat_text = ""
        self.chat_status = "deleting"

user1 = Telegram("User1")
user2 = Telegram("User2")

user1.send(user2, "Hello, how are you?")
user2.read()

user2.delete()
