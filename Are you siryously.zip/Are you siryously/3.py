class Karta:
    card_order = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K']

    def __init__(self, card_name):
        self.card_name = card_name

    def compare(self, other):
        if self.card_order.index(self.card_name) > self.card_order.index(other.card_name):
            return 1 
        elif self.card_order.index(self.card_name) < self.card_order.index(other.card_name):
            return 2
        else:
            return 0 

player1 = Karta('Q')
player2 = Karta('J')

result = player1.compare(player2)

if result == 1:
    print("Player 1 wins!")
elif result == 2:
    print("Player 2 wins!")
else:
    print("It's a draw!")
